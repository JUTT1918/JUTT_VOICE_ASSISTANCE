# JUTT VOICE ASSISTANCE

**JUTT BRAIN** is a production-minded Flask starter for **JUTTSAAB**, designed around Roman Urdu / Pakistani conversational style. It provides a mobile-first dark interface, persistent JSON memory, mood and context handling, goal storage, guarded self-modification proposals, browser speech input/output, and an opt-in GitHub engine.

## Features

- Flask application with `GET /`, `POST /api/chat`, `GET /api/status`, `GET /api/memory`, `POST /api/memory`, and `GET /health`.
- JSON persistence for memories, goals, state, personality, and pending updates.
- Browser SpeechRecognition and SpeechSynthesis hooks where supported.
- Self-modification requests are recorded as pending proposals under `workspace/generated/`; production files are never overwritten automatically.
- GitHub configuration reads only `GITHUB_TOKEN`, `GITHUB_REPO`, and `GITHUB_BRANCH` from the environment. Tokens are never returned by status responses or written to files.
- Railway-ready `Procfile`, pinned Python runtime declaration, health endpoint, and Gunicorn command.

## Local setup

```bash
python -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python main.py
```

Open `http://localhost:5000`. Run the checks with:

```bash
pytest -q
python -m compileall -q .
```

## Environment configuration

Copy `.env.example` to your deployment environment. Never commit `.env` or a token. For the GitHub engine, configure:

```text
GITHUB_TOKEN=<secret injected by the host>
GITHUB_REPO=JUTT1918/JUTT_VOICE_ASSISTANCE
GITHUB_BRANCH=main
```

The application intentionally reports only `configured` or `not_configured` for the token. The GitHub write workflow should be placed behind an explicit approval UI and a review/backup step before production use.

## Railway deployment

Create a Railway service from this repository. Railway will use the `Procfile` and inject `PORT`. Add the environment variables above in the service Variables panel, deploy, and verify `/health` returns `{"ok": true, ...}`. JSON data is suitable for a starter or single-instance deployment; use a managed database and persistent storage before scaling to multiple instances or requiring durable production memory.

## Safety model

JUTT BRAIN can understand requests such as “new feature add karo”, “UI change karo”, and “new command banao”, but it only writes a proposal into the workspace. A future approval workflow should create a backup, run tests, display a diff, and require explicit approval before any GitHub branch or commit operation. Generated code must remain auditable and sandboxed.

## Project layout

The `brain/` package contains the assistant engine, memory, personality, emotions, context, reasoning, goals, command detection, self-modification, sandbox, GitHub client, and safety policy. The `api/` package contains Flask blueprints. The `web/` directory contains the no-dependency frontend. `tests/` contains automated unit tests.
