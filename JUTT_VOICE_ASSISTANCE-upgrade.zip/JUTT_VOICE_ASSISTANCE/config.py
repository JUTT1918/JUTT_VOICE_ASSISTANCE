import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("JUTT_DATA_DIR", BASE_DIR / "data"))
WORKSPACE_DIR = BASE_DIR / "workspace"
GITHUB_REPO = os.getenv("GITHUB_REPO", "JUTT1918/JUTT_VOICE_ASSISTANCE")
GITHUB_BRANCH = os.getenv("GITHUB_BRANCH", "main")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")

def ensure_directories():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for name in ("generated", "tests", "backups"):
        (WORKSPACE_DIR / name).mkdir(parents=True, exist_ok=True)

ensure_directories()
