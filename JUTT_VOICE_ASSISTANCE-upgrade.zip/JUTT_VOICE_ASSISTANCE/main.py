from flask import Flask, jsonify, request, send_from_directory
from brain.brain import JuttBrain
from api.chat import chat_api
from api.system import system_api
from api.memory import memory_api

app = Flask(__name__, static_folder="web", static_url_path="/web")
brain = JuttBrain()
app.register_blueprint(chat_api(brain), url_prefix="/api")
app.register_blueprint(system_api(brain), url_prefix="/api")
app.register_blueprint(memory_api(brain), url_prefix="/api")

@app.get("/")
def index():
    return send_from_directory("web", "index.html")

@app.get("/health")
def health():
    return jsonify({"ok": True, "service": "JUTT VOICE ASSISTANCE"})

@app.errorhandler(404)
def not_found(_):
    return jsonify({"ok": False, "error": "Route nahi mili."}), 404

@app.errorhandler(500)
def server_error(_):
    return jsonify({"ok": False, "error": "Server mein temporary masla hai."}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(__import__("os").environ.get("PORT", 5000)), debug=False)
