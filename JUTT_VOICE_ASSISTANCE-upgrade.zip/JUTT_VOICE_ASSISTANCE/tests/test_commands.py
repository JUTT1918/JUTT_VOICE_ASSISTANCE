from brain.commands import CommandDetector
def test_remember_command(): assert CommandDetector().detect("yaad rakho chai pasand hai")== ("remember", "chai pasand hai")
