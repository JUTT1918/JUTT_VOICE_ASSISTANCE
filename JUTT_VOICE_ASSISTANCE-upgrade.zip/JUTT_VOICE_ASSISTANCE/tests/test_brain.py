from brain.brain import JuttBrain
def test_brain_greeting(tmp_path, monkeypatch):
    monkeypatch.setattr("brain.brain.MemoryStore", lambda: __import__("brain.memory",fromlist=["MemoryStore"]).MemoryStore(tmp_path/"memories.json"))
    b=JuttBrain(); result=b.respond("salam")
    assert "JUTT BRAIN" in result["reply"]
