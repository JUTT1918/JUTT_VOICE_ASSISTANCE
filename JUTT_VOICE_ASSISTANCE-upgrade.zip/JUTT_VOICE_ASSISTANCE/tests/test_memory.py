from brain.memory import MemoryStore
def test_memory_roundtrip(tmp_path):
    store=MemoryStore(tmp_path/"memories.json"); store.add("Mera naam JUTTSAAB hai"); assert len(store.search("jutt saab"))==1
