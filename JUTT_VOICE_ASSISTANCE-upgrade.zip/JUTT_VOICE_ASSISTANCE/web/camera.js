// Camera/vision extension point; permission handling will be added with a vision provider.
