// Memory UI extension point.
