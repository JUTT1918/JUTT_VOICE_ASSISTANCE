from flask import Blueprint, jsonify, request
def chat_api(brain):
    bp=Blueprint("chat",__name__)
    @bp.post("/chat")
    def chat():
        body=request.get_json(silent=True) or {}; text=body.get("message","")
        if not isinstance(text,str) or len(text)>4000: return jsonify({"ok":False,"error":"Message 1 se 4000 characters tak hona chahiye."}),400
        return jsonify({"ok":True,**brain.respond(text)})
    return bp
