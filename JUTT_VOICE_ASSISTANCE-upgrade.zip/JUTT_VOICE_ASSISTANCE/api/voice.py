# Voice API placeholder; browser speech is used without transmitting audio.
