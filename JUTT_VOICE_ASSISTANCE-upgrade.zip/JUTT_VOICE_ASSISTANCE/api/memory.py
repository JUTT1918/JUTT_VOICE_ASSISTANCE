from flask import Blueprint, jsonify, request
def memory_api(brain):
    bp=Blueprint("memory",__name__)
    @bp.get("/memory")
    def memories(): return jsonify({"ok":True,"memories":brain.memory.all()})
    @bp.post("/memory")
    def add_memory():
        body=request.get_json(silent=True) or {}; text=body.get("text","")
        if not isinstance(text,str) or not text.strip(): return jsonify({"ok":False,"error":"Memory text required."}),400
        return jsonify({"ok":True,"memory":brain.memory.add(text)})
    return bp
