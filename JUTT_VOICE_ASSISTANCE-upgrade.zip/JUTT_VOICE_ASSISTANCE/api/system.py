from flask import Blueprint, jsonify
def system_api(brain):
    bp=Blueprint("system",__name__)
    @bp.get("/status")
    def status(): return jsonify({"ok":True,**brain.status()})
    return bp
