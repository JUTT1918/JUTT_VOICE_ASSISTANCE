import json
from pathlib import Path
from config import DATA_DIR
DEFAULT = {"name":"JUTT BRAIN", "owner":"JUTTSAAB", "language":"Roman Urdu", "tone":"respectful, warm, concise"}
def load_personality():
    path = DATA_DIR / "personality.json"
    if not path.exists(): path.write_text(json.dumps(DEFAULT, indent=2), encoding="utf-8")
    try: return {**DEFAULT, **json.loads(path.read_text(encoding="utf-8"))}
    except ValueError: return DEFAULT.copy()
