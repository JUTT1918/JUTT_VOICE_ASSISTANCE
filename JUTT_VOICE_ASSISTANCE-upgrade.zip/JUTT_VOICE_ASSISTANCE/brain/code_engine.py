from .self_modifier import SelfModifier
class CodeEngine:
    def __init__(self): self.modifier=SelfModifier()
    def propose(self, request): return self.modifier.propose(request)
