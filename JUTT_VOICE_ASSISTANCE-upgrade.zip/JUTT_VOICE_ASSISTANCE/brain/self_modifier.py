import json
from datetime import datetime, timezone
from config import WORKSPACE_DIR
class SelfModifier:
    def propose(self, request):
        proposal={"request":request,"status":"pending_approval","created_at":datetime.now(timezone.utc).isoformat(),"rule":"Only workspace files may be generated until explicit approval."}
        path=WORKSPACE_DIR/"generated"/f"proposal-{datetime.now().strftime('%Y%m%d%H%M%S')}.json"; path.write_text(json.dumps(proposal,indent=2),encoding="utf-8"); return proposal
