class SafetyPolicy:
    def can_modify_production(self, approved=False): return bool(approved)
    def redact(self, value):
        if not value: return None
        return "configured"
