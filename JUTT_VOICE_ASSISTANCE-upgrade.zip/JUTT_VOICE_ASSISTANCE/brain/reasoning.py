class ReasoningEngine:
    def classify(self, text):
        t = text.lower()
        if any(x in t for x in ("yaad rakho", "remember", "memory")): return "memory"
        if any(x in t for x in ("feature", "ui change", "command banao", "modify")): return "proposal"
        if any(x in t for x in ("status", "system", "github")): return "status"
        return "conversation"
