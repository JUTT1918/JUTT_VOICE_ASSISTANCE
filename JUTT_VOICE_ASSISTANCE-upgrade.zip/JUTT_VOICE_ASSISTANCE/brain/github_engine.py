import os
import requests
class GitHubEngine:
    def __init__(self): self.repo=os.getenv("GITHUB_REPO","JUTT1918/JUTT_VOICE_ASSISTANCE"); self.branch=os.getenv("GITHUB_BRANCH","main"); self.token=os.getenv("GITHUB_TOKEN")
    @property
    def configured(self): return bool(self.token and self.repo)
    def _headers(self): return {"Authorization":f"Bearer {self.token}","Accept":"application/vnd.github+json"} if self.token else {"Accept":"application/vnd.github+json"}
    def status(self): return {"configured":self.configured,"repo":self.repo,"branch":self.branch,"token":"configured" if self.token else "not_configured"}
    def list_files(self, path=""):
        if not self.configured: raise RuntimeError("GitHub integration is not configured")
        r=requests.get(f"https://api.github.com/repos/{self.repo}/contents/{path}",headers=self._headers(),params={"ref":self.branch},timeout=10); r.raise_for_status(); return r.json()
