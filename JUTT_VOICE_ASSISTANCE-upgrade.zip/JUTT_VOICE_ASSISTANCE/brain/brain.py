from .memory import MemoryStore
from .personality import load_personality
from .emotions import EmotionEngine
from .context import ConversationContext
from .reasoning import ReasoningEngine
from .goals import GoalStore
from .commands import CommandDetector
from .code_engine import CodeEngine
from .github_engine import GitHubEngine
class JuttBrain:
    def __init__(self):
        self.personality=load_personality(); self.memory=MemoryStore(); self.emotions=EmotionEngine(); self.context=ConversationContext(); self.reasoning=ReasoningEngine(); self.goals=GoalStore(); self.commands=CommandDetector(); self.code=CodeEngine(); self.github=GitHubEngine()
    def respond(self, text):
        text=(text or "").strip()
        if not text: return {"reply":"Kuch likho ya mic dabao, JUTTSAAB.","mood":self.emotions.mood}
        self.context.add("user",text); mood=self.emotions.update(text); command,value=self.commands.detect(text)
        if command=="remember":
            item=self.memory.add(value); reply=f"Theek hai JUTTSAAB, yaad rakh liya: {item['text']}"
        elif self.reasoning.classify(text)=="proposal":
            proposal=self.code.propose(text); reply="Samajh gaya. Proposed change workspace mein record kar diya hai; production files ko approval ke baghair touch nahi karunga."
        elif command=="status": reply="JUTT BRAIN online hai. GitHub: " + ("configured" if self.github.configured else "not configured") + "."
        elif any(x in text.lower() for x in ("hello","salam","hi","assalam")): reply="Walaikum assalam JUTTSAAB. Main JUTT BRAIN hoon, aapki service mein hazir hoon."
        else: reply="Samajh gaya JUTTSAAB. Main is baat ko process kar raha hoon. Aap detail dein to main behtar madad kar sakta hoon."
        self.context.add("assistant",reply); return {"reply":reply,"mood":mood,"memory_count":len(self.memory.all())}
    def status(self): return {"name":self.personality["name"],"owner":self.personality["owner"],"mood":self.emotions.mood,"memory_count":len(self.memory.all()),"github":self.github.status()}
