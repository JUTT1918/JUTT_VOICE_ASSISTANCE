class EmotionEngine:
    def __init__(self): self.mood = "focused"
    def update(self, text):
        lowered = text.lower()
        if any(x in lowered for x in ("thanks", "shukriya", "great", "khushi")): self.mood = "happy"
        elif any(x in lowered for x in ("sad", "pareshan", "problem", "ghussa")): self.mood = "supportive"
        else: self.mood = "focused"
        return self.mood
