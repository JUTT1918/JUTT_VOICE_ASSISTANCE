from pathlib import Path
from config import WORKSPACE_DIR
class Sandbox:
    root=WORKSPACE_DIR
    def safe_path(self, name):
        p=(self.root/"generated"/name).resolve(); base=(self.root/"generated").resolve()
        if base not in p.parents: raise ValueError("Unsafe workspace path")
        return p
