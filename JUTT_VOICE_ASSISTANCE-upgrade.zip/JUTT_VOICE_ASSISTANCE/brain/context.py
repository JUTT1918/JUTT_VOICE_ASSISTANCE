from collections import deque
class ConversationContext:
    def __init__(self, limit=12): self.messages = deque(maxlen=limit)
    def add(self, role, content): self.messages.append({"role": role, "content": content})
    def recent(self): return list(self.messages)
