class CommandDetector:
    def detect(self, text):
        t=text.lower().strip()
        if t.startswith(("yaad rakho ", "remember ")): return ("remember", text.split(" ", 2)[-1])
        if t in ("status", "system status", "github status"): return ("status", None)
        return (None, None)
