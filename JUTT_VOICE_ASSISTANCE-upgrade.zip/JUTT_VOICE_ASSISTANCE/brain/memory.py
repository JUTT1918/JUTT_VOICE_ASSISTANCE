import json
from datetime import datetime, timezone
from pathlib import Path
from config import DATA_DIR

class MemoryStore:
    def __init__(self, path=None):
        self.path = Path(path or DATA_DIR / "memories.json")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists(): self._write([])
    def _read(self):
        try: return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError): return []
    def _write(self, data): self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    def add(self, text, kind="note"):
        items = self._read(); item = {"id": len(items)+1, "text": text.strip(), "kind": kind, "created_at": datetime.now(timezone.utc).isoformat()}; items.append(item); self._write(items[-200:]); return item
    def all(self): return self._read()
    def search(self, query):
        normalize = lambda value: "".join(value.lower().split())
        q = normalize(query); return [m for m in self._read() if q in normalize(m.get("text", ""))]
