import json
from config import DATA_DIR
class GoalStore:
    def __init__(self): self.path=DATA_DIR/"goals.json"; self.path.touch(exist_ok=True)
    def all(self):
        try: return json.loads(self.path.read_text() or "[]")
        except ValueError: return []
    def add(self, title):
        goals=self.all(); item={"id":len(goals)+1,"title":title,"done":False}; goals.append(item); self.path.write_text(json.dumps(goals,indent=2)); return item
